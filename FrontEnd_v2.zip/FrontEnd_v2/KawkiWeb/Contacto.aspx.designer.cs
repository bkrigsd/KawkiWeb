﻿//------------------------------------------------------------------------------
// <generado automáticamente>
//     Este código fue generado por una herramienta.
//
//     Los cambios en este archivo podrían causar un comportamiento incorrecto y se perderán si
//     se vuelve a generar el código. 
// </generado automáticamente>
//------------------------------------------------------------------------------

namespace KawkiWeb
{
    public partial class Contacto
    {
        protected global::System.Web.UI.WebControls.ValidationSummary valSummary;

        protected global::System.Web.UI.WebControls.TextBox txtNombre;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator reqNom;

        protected global::System.Web.UI.WebControls.TextBox txtEmail;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator reqMail;
        protected global::System.Web.UI.WebControls.RegularExpressionValidator valMail;

        protected global::System.Web.UI.WebControls.TextBox txtAsunto;

        protected global::System.Web.UI.WebControls.TextBox txtMensaje;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator reqMsg;

        protected global::System.Web.UI.WebControls.Panel pnOk;

        protected global::System.Web.UI.WebControls.Button btnEnviar;
    }
}